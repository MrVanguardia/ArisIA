#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ArisIA - Asistente de IA con aprendizaje autónomo para Linux
"""

import os
import sys
import json
import random
import datetime
import re
import subprocess
import math
import argparse
import threading
import nltk
import numpy as np
import hashlib
import logging
import pickle
import time
from pathlib import Path
from collections import Counter, defaultdict

# Para la interfaz gráfica
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import customtkinter as ctk  # Biblioteca para modernizar la interfaz

# Para procesamiento de lenguaje natural
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Path.home() / ".config" / "arisia" / "arisia.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('ArisIA')

class NLProcessor:
    """Procesador de lenguaje natural para ArisIA"""
    
    def __init__(self):
        self.vectorizer = TfidfVectorizer(
            lowercase=True, 
            stop_words='english',
            ngram_range=(1, 2)
        )
        # Descargar recursos de NLTK si no existen
        self._download_nltk_resources()
        
    def _download_nltk_resources(self):
        """Descarga recursos de NLTK necesarios"""
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt')
        try:
            nltk.data.find('corpora/stopwords')
        except LookupError:
            nltk.download('stopwords')
            
    def tokenize(self, text):
        """Tokeniza texto en palabras"""
        return nltk.word_tokenize(text.lower())
    
    def extract_keywords(self, text, n=5):
        """Extrae palabras clave del texto"""
        tokens = self.tokenize(text)
        freq_dist = nltk.FreqDist(tokens)
        return [word for word, freq in freq_dist.most_common(n)]
    
    def calculate_similarity(self, text1, text2):
        """Calcula la similitud entre dos textos"""
        if not text1 or not text2:
            return 0
        
        try:
            tfidf_matrix = self.vectorizer.fit_transform([text1, text2])
            return cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
        except Exception as e:
            logger.error(f"Error al calcular similitud: {e}")
            return 0
            
    def find_most_similar(self, query, corpus, threshold=0.3):
        """Encuentra la entrada más similar en un corpus"""
        if not corpus:
            return None, 0
            
        best_match = None
        best_score = 0
        
        for item in corpus:
            similarity = self.calculate_similarity(query, item)
            if similarity > best_score and similarity >= threshold:
                best_score = similarity
                best_match = item
                
        return best_match, best_score

class Memory:
    """Sistema de memoria y aprendizaje para ArisIA"""
    
    def __init__(self, memory_path):
        self.memory_path = memory_path
        self.short_term = []
        self.long_term = self._load_memory()
        self.learning_rate = 0.2
        self.max_short_term = 50
        self.max_long_term = 5000
        self.nlp = NLProcessor()
        
    def _load_memory(self):
        """Carga la memoria desde archivo"""
        try:
            if os.path.exists(self.memory_path):
                with open(self.memory_path, 'rb') as f:
                    return pickle.load(f)
            else:
                return {
                    "patterns": {},
                    "responses": {},
                    "facts": {},
                    "user_preferences": {},
                    "conversation_metrics": {
                        "total_interactions": 0,
                        "successful_responses": 0
                    }
                }
        except Exception as e:
            logger.error(f"Error cargando memoria: {e}")
            return {
                "patterns": {},
                "responses": {},
                "facts": {},
                "user_preferences": {},
                "conversation_metrics": {
                    "total_interactions": 0,
                    "successful_responses": 0
                }
            }
    
    def save(self):
        """Guarda la memoria en un archivo"""
        try:
            os.makedirs(os.path.dirname(self.memory_path), exist_ok=True)
            with open(self.memory_path, 'wb') as f:
                pickle.dump(self.long_term, f)
            logger.info("Memoria guardada correctamente")
        except Exception as e:
            logger.error(f"Error guardando memoria: {e}")
    
    def add_to_short_term(self, data):
        """Añade información a la memoria a corto plazo"""
        self.short_term.append(data)
        if len(self.short_term) > self.max_short_term:
            self.short_term.pop(0)
    
    def consolidate_memory(self):
        """Consolida la memoria a corto plazo en la memoria a largo plazo"""
        if not self.short_term:
            return
            
        for item in self.short_term:
            item_type = item.get("type")
            content = item.get("content")
            
            if item_type == "pattern":
                pattern = content.get("pattern")
                response = content.get("response")
                if pattern and response:
                    pattern_hash = self._hash_text(pattern)
                    if pattern_hash in self.long_term["patterns"]:
                        # Actualizar patrón existente
                        existing_responses = self.long_term["patterns"][pattern_hash]["responses"]
                        response_hash = self._hash_text(response)
                        if response_hash in existing_responses:
                            existing_responses[response_hash]["count"] += 1
                        else:
                            existing_responses[response_hash] = {
                                "text": response,
                                "count": 1
                            }
                    else:
                        # Crear nuevo patrón
                        self.long_term["patterns"][pattern_hash] = {
                            "text": pattern,
                            "responses": {
                                self._hash_text(response): {
                                    "text": response,
                                    "count": 1
                                }
                            }
                        }
            
            elif item_type == "fact":
                subject = content.get("subject")
                predicate = content.get("predicate")
                if subject and predicate:
                    subject_hash = self._hash_text(subject)
                    if subject_hash not in self.long_term["facts"]:
                        self.long_term["facts"][subject_hash] = {
                            "subject": subject,
                            "predicates": {}
                        }
                    
                    pred_hash = self._hash_text(predicate)
                    if pred_hash in self.long_term["facts"][subject_hash]["predicates"]:
                        self.long_term["facts"][subject_hash]["predicates"][pred_hash]["confidence"] += self.learning_rate
                    else:
                        self.long_term["facts"][subject_hash]["predicates"][pred_hash] = {
                            "text": predicate,
                            "confidence": self.learning_rate,
                            "last_updated": datetime.datetime.now().isoformat()
                        }
            
            elif item_type == "preference":
                user = content.get("user", "default")
                preference = content.get("preference")
                value = content.get("value")
                if preference and value is not None:
                    if user not in self.long_term["user_preferences"]:
                        self.long_term["user_preferences"][user] = {}
                    self.long_term["user_preferences"][user][preference] = value
        
        # Limpiar memoria a corto plazo después de consolidación
        self.short_term = []
        self.save()
    
    def find_response(self, query, threshold=0.7):
        """Busca una respuesta adecuada basada en patrones aprendidos"""
        for pattern_hash, pattern_data in self.long_term["patterns"].items():
            similarity = self.nlp.calculate_similarity(query, pattern_data["text"])
            if similarity >= threshold:
                # Encontrar la respuesta más frecuente
                responses = pattern_data["responses"]
                if not responses:
                    continue
                    
                best_response = None
                max_count = 0
                
                for resp_hash, resp_data in responses.items():
                    if resp_data["count"] > max_count:
                        max_count = resp_data["count"]
                        best_response = resp_data["text"]
                
                return best_response
        
        return None
    
    def learn_pattern(self, query, response):
        """Aprende un nuevo patrón de pregunta-respuesta"""
        self.add_to_short_term({
            "type": "pattern",
            "content": {
                "pattern": query,
                "response": response
            }
        })
    
    def learn_fact(self, subject, predicate):
        """Aprende un nuevo hecho"""
        self.add_to_short_term({
            "type": "fact",
            "content": {
                "subject": subject,
                "predicate": predicate
            }
        })
        
    def get_fact(self, subject):
        """Recupera hechos sobre un tema específico"""
        subject_hash = self._hash_text(subject)
        if subject_hash in self.long_term["facts"]:
            facts = []
            for pred_hash, pred_data in self.long_term["facts"][subject_hash]["predicates"].items():
                if pred_data["confidence"] > 0.5:  # Solo hechos con cierta confianza
                    facts.append(pred_data["text"])
            return facts
        return []
    
    def _hash_text(self, text):
        """Genera un hash único para un texto"""
        return hashlib.md5(text.lower().encode()).hexdigest()
    
    def update_metrics(self, success=True):
        """Actualiza métricas de conversación"""
        self.long_term["conversation_metrics"]["total_interactions"] += 1
        if success:
            self.long_term["conversation_metrics"]["successful_responses"] += 1

class ArisIA:
    """Asistente de IA con capacidad de aprendizaje autónomo"""
    
    def __init__(self):
        self.name = "ArisIA"
        self.version = "2.0.0"
        self.config_dir = Path.home() / ".config" / "arisia"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        self.knowledge_base_path = self.config_dir / "knowledge_base.json"
        self.memory_path = self.config_dir / "memory.pkl"
        
        self.knowledge_base = self._load_knowledge_base()
        self.memory = Memory(self.memory_path)
        self.nlp = NLProcessor()
        
        self.conversation_history = []
        self.max_history = 20
        self.learning_mode = True
        
        # Iniciar hilo de consolidación periódica de memoria
        self.memory_thread = threading.Thread(target=self._periodic_memory_consolidation, daemon=True)
        self.memory_thread.start()
    
    def _periodic_memory_consolidation(self):
        """Consolida la memoria periódicamente"""
        while True:
            # Consolidar cada 5 minutos
            time.sleep(300)
            logger.info("Consolidando memoria...")
            self.memory.consolidate_memory()
    
    def _load_knowledge_base(self):
        """Carga la base de conocimiento desde un archivo JSON o crea una por defecto"""
        if self.knowledge_base_path.exists():
            try:
                with open(self.knowledge_base_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error al cargar la base de conocimiento: {e}")
                return self._create_default_knowledge_base()
        else:
            return self._create_default_knowledge_base()
    
    def _create_default_knowledge_base(self):
        """Crea una base de conocimiento por defecto"""
        kb = {
            "respuestas": {
                "saludo": ["Hola", "Saludos", "¿En qué puedo ayudarte?", "¡Bienvenido!"],
                "despedida": ["Adiós", "Hasta pronto", "Que tengas un buen día", "Nos vemos pronto"],
                "agradecimiento": ["De nada", "Un placer", "Estoy para ayudarte", "Me alegra poder ayudar"],
                "default": ["No entiendo esa consulta", "¿Podrías reformular la pregunta?", "Necesito más información para entender tu consulta"]
            },
            "comandos": {
                "fecha": "date",
                "hora": "date +%H:%M:%S",
                "calendario": "cal",
                "archivos": "ls -la",
                "memoria": "free -h",
                "espacio": "df -h",
                "procesos": "ps aux",
                "sistema": "uname -a",
                "actualizaciones": "apt list --upgradable 2>/dev/null || dnf check-update 2>/dev/null || pacman -Qu 2>/dev/null"
            },
            "informacion": {
                "linux": "Linux es un sistema operativo de código abierto basado en UNIX, desarrollado originalmente por Linus Torvalds.",
                "python": "Python es un lenguaje de programación interpretado de alto nivel y propósito general, creado por Guido van Rossum.",
                "arisia": "ArisIA es un asistente de IA para sistemas Linux con capacidad de aprendizaje autónomo."
            }
        }
        
        # Guardar base de conocimiento
        try:
            with open(self.knowledge_base_path, 'w', encoding='utf-8') as f:
                json.dump(kb, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Error al crear la base de conocimiento: {e}")
        
        return kb
    
    def process_input(self, user_input):
        """Procesa la entrada del usuario y genera una respuesta"""
        if not user_input or user_input.strip() == "":
            return "¿En qué puedo ayudarte?"
            
        self.conversation_history.append({"user": user_input})
        
        # Mantener historial limitado
        if len(self.conversation_history) > self.max_history:
            self.conversation_history = self.conversation_history[-self.max_history:]
        
        # Convertir a minúsculas para facilitar el procesamiento
        user_input_lower = user_input.lower()
        
        # Buscar primero en memoria para ver si hay respuestas aprendidas
        learned_response = self.memory.find_response(user_input)
        if learned_response:
            self.conversation_history[-1]["response"] = learned_response
            self.memory.update_metrics(success=True)
            return learned_response
        
        # Verificar si es una pregunta sobre la hora o fecha
        if re.search(r'\b(hora|hora actual|qué hora es)\b', user_input_lower):
            response = self.ejecutar_comando("hora")
        elif re.search(r'\b(fecha|día|qué día es hoy|fecha actual)\b', user_input_lower):
            response = self.ejecutar_comando("fecha")
        
        # Verificar si es una solicitud para mostrar archivos
        elif re.search(r'\b(archivos|mostrar archivos|listar archivos|listar directorio)\b', user_input_lower):
            response = self.ejecutar_comando("archivos")
        
        # Verificar si es una solicitud de información del sistema
        elif re.search(r'\b(sistema|información del sistema|sistema operativo)\b', user_input_lower):
            response = self.ejecutar_comando("sistema")
        
        # Verificar si es una consulta de memoria disponible
        elif re.search(r'\b(memoria|ram|memoria disponible)\b', user_input_lower):
            response = self.ejecutar_comando("memoria")
        
        # Verificar si es una consulta de espacio en disco
        elif re.search(r'\b(espacio|disco|almacenamiento)\b', user_input_lower):
            response = self.ejecutar_comando("espacio")
        
        # Verificar actualizaciones disponibles
        elif re.search(r'\b(actualizaciones|actualizar|paquetes)\b', user_input_lower):
            response = self.ejecutar_comando("actualizaciones")
        
        # Verificar si es una operación matemática
        elif re.search(r'[-+*/\d()]+', user_input_lower) and re.search(r'(calcula|calcular|cuánto es)', user_input_lower):
            try:
                # Extraer la expresión matemática
                expression = re.sub(r'[^-+*/\d().]', '', user_input)
                result = eval(expression)
                response = f"El resultado de {expression} es {result}"
            except Exception:
                response = "No pude realizar esa operación matemática."
        
        # Verificar si es una pregunta sobre aprendizaje
        elif re.search(r'\b(aprender|enseñar|recuerda)\b', user_input_lower):
            # Buscar un patrón de "aprende que X es Y"
            match = re.search(r'(?:aprende|enseñar|recuerda) (?:que )?(.*?) (?:es|son) (.*)', user_input_lower)
            if match:
                subject = match.group(1).strip()
                predicate = match.group(2).strip()
                self.memory.learn_fact(subject, predicate)
                response = f"He aprendido que {subject} es {predicate}. Gracias por enseñarme."
            else:
                response = "Si quieres que aprenda algo nuevo, puedes decirme 'aprende que X es Y'."
        
        # Verificar si es una pregunta sobre algo que ha aprendido
        elif re.search(r'\b(qué es|quién es|cuál es|dime sobre)\b', user_input_lower):
            # Extraer el tema de la pregunta
            match = re.search(r'(?:qué es|quién es|cuál es|dime sobre) (.*?)(?:\?|$)', user_input_lower)
            if match:
                subject = match.group(1).strip()
                facts = self.memory.get_fact(subject)
                
                if facts:
                    response = f"Sobre {subject}, sé que: " + "; ".join(facts)
                else:
                    # Buscar en la base de conocimiento estática
                    for key, info in self.knowledge_base["informacion"].items():
                        if key in subject:
                            response = info
                            break
                    else:
                        response = f"No tengo información sobre {subject}. ¿Quieres enseñarme algo al respecto?"
            else:
                response = self._get_response("default")
        
        # Verificar saludos, despedidas, etc.
        elif re.search(r'\b(hola|saludos|buenos días|buenas tardes|buenas noches)\b', user_input_lower):
            response = self._get_response("saludo")
        elif re.search(r'\b(adiós|chao|hasta luego|hasta pronto|nos vemos)\b', user_input_lower):
            response = self._get_response("despedida")
        elif re.search(r'\b(gracias|te lo agradezco|muchas gracias)\b', user_input_lower):
            response = self._get_response("agradecimiento")
        
        # Si no se ha identificado ningún patrón, devolver respuesta por defecto
        else:
            response = self._get_response("default")
        
        # Guardar la respuesta en el historial
        self.conversation_history[-1]["response"] = response
        
        # Aprender de esta interacción
        if self.learning_mode:
            self.memory.learn_pattern(user_input, response)
            self.memory.update_metrics(success=True)
        
        return response
    
    def _get_response(self, category):
        """Obtiene una respuesta aleatoria de la categoría especificada"""
        if category in self.knowledge_base["respuestas"]:
            return random.choice(self.knowledge_base["respuestas"][category])
        return random.choice(self.knowledge_base["respuestas"]["default"])
    
    def ejecutar_comando(self, comando):
        """Ejecuta un comando del sistema"""
        if comando in self.knowledge_base["comandos"]:
            try:
                cmd = self.knowledge_base["comandos"][comando]
                output = subprocess.check_output(cmd, shell=True, text=True)
                return output.strip()
            except Exception as e:
                return f"Error al ejecutar el comando: {e}"
        return "Comando no reconocido."
    
    def show_history(self):
        """Muestra el historial de conversación"""
        if not self.conversation_history:
            return "No hay historial de conversación."
        
        history_text = "Historial de conversación:\n"
        for i, exchange in enumerate(self.conversation_history, 1):
            history_text += f"{i}. Usuario: {exchange['user']}\n"
            if "response" in exchange:
                history_text += f"   {self.name}: {exchange['response']}\n"
        
        return history_text
    
    def get_info(self):
        """Devuelve información sobre ArisIA"""
        return f"""
{self.name} v{self.version}
Un asistente de IA con capacidad de aprendizaje autónomo para Linux.
Desarrollado con Python y tecnologías de procesamiento de lenguaje natural.

Capacidades:
- Responder preguntas y ejecutar comandos del sistema.
- Aprender de las interacciones con el usuario.
- Almacenar y recuperar información personalizada.
- Realizar cálculos matemáticos.
- Adaptarse a tus preferencias con el tiempo.
"""

    def toggle_learning(self):
        """Activa o desactiva el modo de aprendizaje"""
        self.learning_mode = not self.learning_mode
        return f"Modo de aprendizaje {'activado' if self.learning_mode else 'desactivado'}"

# Interfaz gráfica moderna con customtkinter
class ArisIAGUI:
    """Interfaz gráfica para ArisIA"""
    
    def __init__(self, root):
        self.root = root
        self.arisia = ArisIA()
        self.setup_ui()
        
    def setup_ui(self):
        """Configura la interfaz de usuario"""
        # Configurar tema
        ctk.set_appearance_mode("dark")  # Modes: "dark", "light"
        ctk.set_default_color_theme("blue")  # Themes: "blue" (standard), "green", "dark-blue"
        
        # Configurar ventana principal
        self.root.title(f"{self.arisia.name} v{self.arisia.version}")
        self.root.geometry("900x600")
        
        # Crear marco principal
        self.main_frame = ctk.CTkFrame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Marco de mensajes
        self.messages_frame = ctk.CTkFrame(self.main_frame)
        self.messages_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(10, 5))
        
        # Área de chat
        self.chat_display = ctk.CTkTextbox(self.messages_frame, width=60, height=20)
        self.chat_display.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.chat_display.configure(state="disabled")
        
        # Marco de entrada de usuario
        self.input_frame = ctk.CTkFrame(self.main_frame)
        self.input_frame.pack(fill=tk.X, expand=False, padx=10, pady=(5, 10))
        
        # Entrada de texto
        self.user_input = ctk.CTkEntry(self.input_frame, placeholder_text="Escribe tu mensaje aquí...")
        self.user_input.pack(fill=tk.X, expand=True, side=tk.LEFT, padx=(5, 5), pady=5)
        self.user_input.bind("<Return>", self.send_message)
        
        # Botón de envío
        self.send_button = ctk.CTkButton(self.input_frame, text="Enviar", command=self.send_message)
        self.send_button.pack(side=tk.RIGHT, padx=5, pady=5)
        
        # Marco de botones de acción
        self.action_frame = ctk.CTkFrame(self.main_frame)
        self.action_frame.pack(fill=tk.X, expand=False, padx=10, pady=(5, 10))
        
        # Botones de acción
        self.clear_button = ctk.CTkButton(self.action_frame, text="Limpiar Chat", 
                                         command=self.clear_chat, fg_color="gray30")
        self.clear_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.learning_button = ctk.CTkButton(self.action_frame, text="Desactivar Aprendizaje", 
                                           command=self.toggle_learning, fg_color="gray30")
        self.learning_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.info_button = ctk.CTkButton(self.action_frame, text="Información", 
                                        command=self.show_info, fg_color="gray30")
        self.info_button.pack(side=tk.LEFT, padx=5, pady=5)
        
        # Mensaje de bienvenida
        self.insert_ai_message("¡Hola! Soy ArisIA, tu asistente de IA para Linux. ¿En qué puedo ayudarte hoy?")
        
        # Focus en la entrada de texto
        self.user_input.focus_set()
    
    def send_message(self, event=None):
        """Procesa el mensaje del usuario y muestra la respuesta"""
        user_text = self.user_input.get().strip()
        if not user_text:
            return
            
        # Mostrar mensaje del usuario
        self.insert_user_message(user_text)
        
        # Limpiar entrada
        self.user_input.delete(0, tk.END)
        
        # Procesar entrada y mostrar respuesta de ArisIA
        self.root.after(100, lambda: self.process_and_display(user_text))
    
    def process_and_display(self, user_text):
        """Procesa la entrada y muestra la respuesta de ArisIA"""
        response = self.arisia.process_input(user_text)
        self.insert_ai_message(response)
    
    def insert_user_message(self, message):
        """Inserta mensaje del usuario en el chat"""
        self.chat_display.configure(state="normal")
        self.chat_display.insert(tk.END, "\n\nTú: ", "user_tag")
        self.chat_display.insert(tk.END, message)
        self.chat_display.see(tk.END)
        self.chat_display.configure(state="disabled")
    
    def insert_ai_message(self, message):
        """Inserta mensaje de ArisIA en el chat"""
        self.chat_display.configure(state="normal")
        self.chat_display.insert(tk.END, f"\n\n{self.arisia.name}: ", "ai_tag")
        self.chat_display.insert(tk.END, message)
        self.chat_display.see(tk.END)
        self.chat_display.configure(state="disabled")
    
    def clear_chat(self):
        """Limpia el historial de chat en la interfaz"""
        self.chat_display.configure(state="normal")
        self.chat_display.delete(1.0, tk.END)
        self.chat_display.configure(state="disabled")
        self.insert_ai_message("Chat limpiado. ¿En qué puedo ayudarte?")
    
    def toggle_learning(self):
        """Activa o desactiva el modo de aprendizaje"""
        result = self.arisia.toggle_learning()
        self.insert_ai_message(result)
        self.learning_button.configure(
            text=f"{'Activar' if not self.arisia.learning_mode else 'Desactivar'} Aprendizaje"
        )
    
    def show_info(self):
        """Muestra información sobre ArisIA"""
        info_text = self.arisia.get_info()
        self.insert_ai_message(info_text)

# Instalador para diferentes distribuciones Linux
class ArisIAInstaller:
    """Instalador para ArisIA en diferentes distribuciones Linux"""
    
    def __init__(self):
        self.source_dir = os.path.dirname(os.path.abspath(__file__))
        self.install_dir = '/opt/arisia'
        self.bin_dir = '/usr/local/bin'
        self.desktop_dir = '/usr/share/applications'
        self.icon_dir = '/usr/share/icons/hicolor/128x128/apps'
    
    def detect_distro(self):
        """Detecta la distribución Linux"""
        try:
            if os.path.exists('/etc/os-release'):
                with open('/etc/os-release', 'r') as f:
                    content = f.read()
                    if 'ID=ubuntu' in content or 'ID=debian' in content:
                        return 'debian'
                    elif 'ID=fedora' in content:
                        return 'fedora'
                    elif 'ID=arch' in content or 'ID=manjaro' in content:
                        return 'arch'
            return 'unknown'
        except Exception as e:
            logger.error(f"Error detectando distribución: {e}")
            return 'unknown'
    
    def get_dependencies(self, distro):
        """Obtiene los comandos para instalar dependencias según la distribución"""
        base_deps = "python3 python3-pip python3-venv python3-tk git"
        
        if distro == 'debian':
            return f"apt-get update && apt-get install -y {base_deps} python3-dev"
        elif distro == 'fedora':
            return f"dnf install -y {base_deps} python3-devel"
        elif distro == 'arch':
            return f"pacman -Sy --noconfirm {base_deps} python-dev"
        else:
            return None
    
    def install(self):
        """Instala ArisIA en el sistema"""
        try:
            # Detectar distribución
            distro = self.detect_distro()
            logger.info(f"Distribución detectada: {distro}")
            
            if distro == 'unknown':
                print("No se pudo detectar una distribución compatible. Instalando de forma genérica...")
            
            # Crear directorios de instalación si no existen
            for directory in [self.install_dir, self.bin_dir, self.desktop_dir, self.icon_dir]:
                os.makedirs(directory, exist_ok=True)
            
            # Copiar archivos
            print("Copiando archivos...")
            
            # Crear virtualenv para ArisIA
            venv_dir = os.path.join(self.install_dir, 'venv')
            subprocess.run(['python3', '-m', 'venv', venv_dir], check=True)
            
            # Instalar dependencias en el virtualenv
            pip = os.path.join(venv_dir, 'bin', 'pip')
            subprocess.run([pip, 'install', '--upgrade', 'pip'], check=True)
            subprocess.run([pip, 'install', 'customtkinter', 'nltk', 'scikit-learn', 'numpy'], check=True)
            
            # Copiar archivos del programa
            shutil.copy(os.path.join(self.source_dir, 'arisia.py'), self.install_dir)
            shutil.copy(os.path.join(self.source_dir, 'arisia_icon.png'), self.icon_dir)
            
            # Crear script launcher
            with open(os.path.join(self.bin_dir, 'arisia'), 'w') as f:
                f.write(f"""#!/bin/bash
source {os.path.join(self.install_dir, 'venv', 'bin', 'activate')}
python {os.path.join(self.install_dir, 'arisia.py')} "$@"
""")
            os.chmod(os.path.join(self.bin_dir, 'arisia'), 0o755)
            
            # Crear archivo .desktop
            with open(os.path.join(self.desktop_dir, 'arisia.desktop'), 'w') as f:
                f.write(f"""[Desktop Entry]
Name=ArisIA
Comment=Asistente de IA con aprendizaje autónomo para Linux
Exec={os.path.join(self.bin_dir, 'arisia')}
Icon={os.path.join(self.icon_dir, 'arisia_icon.png')}
Terminal=false
Type=Application
Categories=Utility;AI;
Keywords=AI;Assistant;Intelligence;
""")
            
            print(f"""
¡ArisIA instalado correctamente!

Puedes iniciar ArisIA de las siguientes formas:
1. Desde el menú de aplicaciones busca "ArisIA"
2. Ejecutando 'arisia' en una terminal

Para desinstalar:
sudo arisia --uninstall
""")
            return True
            
        except Exception as e:
            logger.error(f"Error de instalación: {e}")
            print(f"Error durante la instalación: {e}")
            return False
    
    def uninstall(self):
        """Desinstala ArisIA del sistema"""
        try:
            # Eliminar archivos
            print("Desinstalando ArisIA...")
            
            # Eliminar archivo desktop
            if os.path.exists(os.path.join(self.desktop_dir, 'arisia.desktop')):
                os.remove(os.path.join(self.desktop_dir, 'arisia.desktop'))
            
            # Eliminar icono
            if os.path.exists(os.path.join(self.icon_dir, 'arisia_icon.png')):
                os.remove(os.path.join(self.icon_dir, 'arisia_icon.png'))
            
            # Eliminar script launcher
            if os.path.exists(os.path.join(self.bin_dir, 'arisia')):
                os.remove(os.path.join(self.bin_dir, 'arisia'))
            
            # Eliminar directorio de instalación
            if os.path.exists(self.install_dir):
                shutil.rmtree(self.install_dir)
            
            print("ArisIA ha sido desinstalado correctamente.")
            return True
            
        except Exception as e:
            logger.error(f"Error de desinstalación: {e}")
            print(f"Error durante la desinstalación: {e}")
            return False

# Punto de entrada principal
def main():
    import time  # Importado aquí para evitar problemas con el thread de memoria
    
    parser = argparse.ArgumentParser(description="ArisIA - Asistente de IA con aprendizaje autónomo para Linux")
    parser.add_argument('-i', '--interactive', action='store_true', help='Modo interactivo por consola')
    parser.add_argument('-g', '--gui', action='store_true', help='Iniciar interfaz gráfica (por defecto)')
    parser.add_argument('--install', action='store_true', help='Instalar ArisIA en el sistema')
    parser.add_argument('--uninstall', action='store_true', help='Desinstalar ArisIA del sistema')
    parser.add_argument('query', nargs='*', help='Consulta para ArisIA')
    
    args = parser.parse_args()
    
    # Instalación/desinstalación
    if args.install:
        installer = ArisIAInstaller()
        installer.install()
        return
    
    if args.uninstall:
        installer = ArisIAInstaller()
        installer.uninstall()
        return
    
    ai = ArisIA()
    
    # Modo consola interactiva
    if args.interactive:
        print(f"Bienvenido a {ai.name} v{ai.version}")
        print("Escribe 'salir', 'exit' o 'quit' para terminar.")
        print("Escribe 'ayuda' o 'help' para ver comandos disponibles.")
        
        while True:
            try:
                user_input = input("> ")
                
                if user_input.lower() in ['salir', 'exit', 'quit']:
                    print(f"{ai.name}: Hasta pronto!")
                    ai.memory.consolidate_memory()  # Guardar memoria antes de salir
                    break
                elif user_input.lower() in ['ayuda', 'help']:
                    print("\nComandos disponibles:")
                    print("- fecha/hora: Muestra la fecha u hora actual")
                    print("- archivos: Lista los archivos en el directorio actual")
                    print("- sistema: Muestra información del sistema")
                    print("- memoria: Muestra uso de memoria RAM")
                    print("- espacio: Muestra espacio en disco")
                    print("- historial: Muestra el historial de conversación")
                    print("- info: Muestra información sobre ArisIA")
                    print("- aprender: Activa/desactiva modo de aprendizaje")
                    print("- aprende que X es Y: Enseña algo a ArisIA")
                    print("- salir/exit/quit: Termina el programa\n")
                elif user_input.lower() == 'historial':
                    print(ai.show_history())
                elif user_input.lower() == 'info':
                    print(ai.get_info())
                elif user_input.lower() == 'aprender':
                    print(ai.toggle_learning())
                else:
                    response = ai.process_input(user_input)
                    print(f"{ai.name}: {response}")
            except KeyboardInterrupt:
                print("\n¡Adiós!")
                ai.memory.consolidate_memory()  # Guardar memoria antes de salir
                break
            except Exception as e:
                print(f"Error: {e}")
    
    # Consulta directa
    elif args.query:
        query = ' '.join(args.query)
        response = ai.process_input(query)
        print(response)
    
    # Modo GUI (por defecto)
    else:
        root = ctk.CTk()
        app = ArisIAGUI(root)
        root.protocol("WM_DELETE_WINDOW", lambda: [ai.memory.consolidate_memory(), root.destroy()])
        root.mainloop()

if __name__ == "__main__":
    main()