#!/bin/bash
# Instalador de ArisIA - Asistente de IA con aprendizaje autónomo para Linux

# Colores para los mensajes
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Función para mostrar el banner
show_banner() {
    echo -e "${BLUE}"
    echo "    _         _     _____ _    "
    echo "   / \   _ __(_)___/  ___/_\   "
    echo "  / _ \ | '__| / __\ |_ //_\\  "
    echo " / ___ \| |  | \__ \  _/  _  \ "
    echo "/_/   \_\_|  |_|___/_| \_/ \_/ "
    echo -e "${NC}"
    echo -e "${YELLOW}Asistente de IA con aprendizaje autónomo para Linux${NC}"
    echo ""
}

# Función para verificar privilegios de root
check_root() {
    if [ "$(id -u)" != "0" ]; then
        echo -e "${RED}Este script debe ejecutarse como root${NC}"
        echo "Por favor, ejecute: sudo $0"
        exit 1
    fi
}

# Función para detectar la distribución Linux
detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if [[ "$ID" == "ubuntu" || "$ID" == "debian" || "$ID_LIKE" == *"debian"* ]]; then
            echo "debian"
        elif [[ "$ID" == "fedora" || "$ID_LIKE" == *"fedora"* ]]; then
            echo "fedora"
        elif [[ "$ID" == "arch" || "$ID" == "manjaro" || "$ID_LIKE" == *"arch"* ]]; then
            echo "arch"
        else
            echo "unknown"
        fi
    else
        echo "unknown"
    fi
}

# Función para instalar dependencias
install_dependencies() {
    local distro=$1
    echo -e "${BLUE}Instalando dependencias...${NC}"
    
    case $distro in
        debian)
            apt-get update
            apt-get install -y python3 python3-pip python3-venv python3-tk git python3-dev
            ;;
        fedora)
            dnf install -y python3 python3-pip python3-tkinter git python3-devel
            ;;
        arch)
            pacman -Sy --noconfirm python python-pip python-virtualenv tk git
            ;;
        *)
            echo -e "${YELLOW}Distribución no reconocida. Instale manualmente las siguientes dependencias:${NC}"
            echo "- python3"
            echo "- python3-pip"
            echo "- python3-venv o virtualenv"
            echo "- python3-tk"
            echo "- git"
            read -p "¿Continuar con la instalación? (s/n): " response
            if [[ "$response" != "s" && "$response" != "S" ]]; then
                echo -e "${RED}Instalación cancelada${NC}"
                exit 1
            fi
            ;;
    esac
}

# Función para crear el icono de la aplicación
create_icon() {
    ICON_PATH="/usr/share/icons/hicolor/128x128/apps"
    mkdir -p "$ICON_PATH"
    cat > "$ICON_PATH/arisia_icon.svg" << 'EOL'
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
  <defs>
    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#3498db;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#9b59b6;stop-opacity:1" />
    </linearGradient>
  </defs>
  <circle cx="64" cy="64" r="60" fill="url(#grad1)" />
  <circle cx="64" cy="64" r="50" fill="#2c3e50" />
  <circle cx="64" cy="64" r="45" fill="#34495e" />
  
  <!-- Patrón de circuito -->
  <path d="M64,25 L64,40 M64,88 L64,103 M25,64 L40,64 M88,64 L103,64" 
        stroke="#3498db" stroke-width="3" stroke-linecap="round" />
  <path d="M38,38 L48,48 M80,80 L90,90 M38,90 L48,80 M80,48 L90,38" 
        stroke="#3498db" stroke-width="2" stroke-linecap="round" />
  
  <!-- Brillo/reflejo -->
  <circle cx="45" cy="45" r="6" fill="#ffffff" fill-opacity="0.3" />
  
  <!-- Iris de IA -->
  <circle cx="64" cy="64" r="20" fill="#3498db" />
  <circle cx="64" cy="64" r="12" fill="#2980b9" />
  <circle cx="64" cy="64" r="5" fill="#ffffff" />
  
  <!-- Destello de energía -->
  <path d="M60,59 L53,51 L57,58 L51,60 L59,63 L55,67 L64,64 L68,70 L67,62 L73,64 L68,59 L75,56 L64,54 Z" 
        fill="#ffffff" fill-opacity="0.8" />
</svg>
EOL
}

# Función para crear el archivo de escritorio
create_desktop_file() {
    local install_dir=$1
    mkdir -p /usr/share/applications
    cat > /usr/share/applications/arisia.desktop << EOL
[Desktop Entry]
Name=ArisIA
GenericName=Asistente IA
Comment=Asistente de IA con aprendizaje autónomo para Linux
Exec=${install_dir}/venv/bin/python ${install_dir}/arisia.py
Icon=/usr/share/icons/hicolor/128x128/apps/arisia_icon.svg
Terminal=false
Type=Application
Categories=Utility;AI;
Keywords=AI;Assistant;Intelligence;
StartupNotify=true
EOL
}

# Función principal de instalación
install_arisia() {
    local install_dir="/opt/arisia"
    local bin_path="/usr/local/bin/arisia"
    local temp_dir=$(mktemp -d)
    
    # Crear directorios
    mkdir -p "$install_dir"
    
    # Descargar o copiar el código fuente de ArisIA
    echo -e "${BLUE}Configurando ArisIA...${NC}"
    
    # Crear entorno virtual
    python3 -m venv "${install_dir}/venv"
    source "${install_dir}/venv/bin/activate"
    
    # Actualizar pip e instalar dependencias
    pip install --upgrade pip
    pip install customtkinter nltk scikit-learn numpy
    
    # Descargar nltk data
    python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords')"
    
    # Copiar el archivo principal
    cp "$temp_dir/arisia.py" "$install_dir/"
    chmod +x "$install_dir/arisia.py"
    
    # Crear enlace simbólico para acceso global
    cat > "$bin_path" << EOL
#!/bin/bash
source "${install_dir}/venv/bin/activate"
python "${install_dir}/arisia.py" "\$@"
EOL
    chmod +x "$bin_path"
    
    # Crear icono y archivo desktop
    create_icon
    create_desktop_file "$install_dir"
    
    # Refrescar caché de iconos
    if command -v gtk-update-icon-cache &> /dev/null; then
        gtk-update-icon-cache -f -t /usr/share/icons/hicolor
    fi
    
    echo -e "${GREEN}¡Instalación de ArisIA completada con éxito!${NC}"
    echo ""
    echo -e "Puedes iniciar ArisIA de las siguientes formas:"
    echo -e "1. Desde el menú de aplicaciones busca ${BLUE}ArisIA${NC}"
    echo -e "2. Ejecutando ${BLUE}arisia${NC} en una terminal"
    echo ""
}

# Función de desinstalación
uninstall_arisia() {
    echo -e "${YELLOW}Desinstalando ArisIA...${NC}"
    
    # Eliminar archivos
    rm -f /usr/share/applications/arisia.desktop
    rm -f /usr/share/icons/hicolor/128x128/apps/arisia_icon.svg
    rm -f /usr/local/bin/arisia
    rm -rf /opt/arisia
    
    # Refrescar caché de iconos
    if command -v gtk-update-icon-cache &> /dev/null; then
        gtk-update-icon-cache -f -t /usr/share/icons/hicolor
    fi
    
    echo -e "${GREEN}ArisIA ha sido desinstalado correctamente.${NC}"
}

# Punto de entrada principal
main() {
    show_banner
    check_root
    
    if [ "$1" == "--uninstall" ]; then
        uninstall_arisia
        exit 0
    fi
    
    echo -e "${YELLOW}Este instalador configurará ArisIA en su sistema.${NC}"
    echo ""
    
    # Detectar distribución
    distro=$(detect_distro)
    echo -e "Distribución detectada: ${BLUE}$distro${NC}"
    
    # Instalar dependencias
    install_dependencies "$distro"
    
# Copiar el archivo real de la IA
cp "$(dirname "$0")/arisia.py" "$temp_dir/"
    
    # Instalar ArisIA
    install_arisia
}

# Ejecutar el instalador
main "$@"
